import QRCode from "qrcode";
import sharp from "sharp";

export function makeQrToken(id) {
  return `GUBAE-EVENT:${String(id)}`;
}

export async function ensureQrToken(booking) {
  const expected = makeQrToken(booking._id);
  if (booking.qrToken === expected) return expected;
  booking.qrToken = expected;
  await booking.save();
  return expected;
}

export function qrPayloadFor(booking) {
  return booking.qrToken || makeQrToken(booking._id);
}

function escapeXml(value = "") {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

export async function qrPngFor(booking) {
  const token = qrPayloadFor(booking);
  const name = escapeXml(booking.name || "Participant");
  const organization = escapeXml(booking.organization || "");

  // Generate the QR itself as SVG, then rasterize one complete SVG canvas.
  // This is more reliable than compositing separate PNG/SVG inputs with Sharp.
  const qrSvg = await QRCode.toString(token, {
    type: "svg",
    width: 700,
    margin: 3,
    errorCorrectionLevel: "M",
  });

  const qrSvgEscaped = qrSvg
    .replace(/<\?xml[^>]*>/i, "")
    .replace(/<!DOCTYPE[^>]*>/i, "");

  const canvasSvg = `
    <svg width="760" height="900" viewBox="0 0 760 900" xmlns="http://www.w3.org/2000/svg">
      <rect width="760" height="900" fill="#ffffff"/>
      <text x="380" y="42" text-anchor="middle"
        font-family="Arial, sans-serif" font-size="28" font-weight="700" fill="#003B46">
        ${name}
      </text>
      ${organization ? `<text x="380" y="76" text-anchor="middle" font-family="Arial, sans-serif" font-size="18" fill="#5b6770">${organization}</text>` : ""}
      <g transform="translate(30,105)">
        ${qrSvgEscaped.replace(/^<svg[^>]*>|<\/svg>$/gi, "")}
      </g>
    </svg>
  `;

  return sharp(Buffer.from(canvasSvg))
    .png()
    .toBuffer();
}
export async function qrDataUrlForToken(token) {
  if (!token) throw new Error("Participant QR token is required");
  return QRCode.toDataURL(token, {
    width: 700,
    margin: 3,
    errorCorrectionLevel: "M",
  });
}

export function safeFileName(value = "participant") {
  return String(value)
    .replace(/[<>:"/\\|?*\u0000-\u001F]/g, "")
    .replace(/[. ]+$/g, "")
    .trim()
    .slice(0, 120) || "participant";
}
